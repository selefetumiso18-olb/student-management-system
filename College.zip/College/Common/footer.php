<footer>
  <div class="footer-top">
    <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>UNDERGRADUATE PROGRAMS</h2>
            <ul>
            <li><a href="">Level 1_4. Informetion And Technology(ICT)</a></li>
              <li><a href="">Level 1_4. Civil Engineering</a></li>
              <li><a href="">Level 1_4. Electrical Engineering</a></li>
              <li><a href="">Level 1_4. Mechanical Engineering</a></li>
              <li><a href="">.Level 1_4. Architecture</a></li>
              <li><a href="">Level 1_4.Computer Science</a></li>
              
            </ul>
          </div>  
          <div class="col-md-3 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>CONTACT DETAILS</h2>
              <p>Address: Gimbichu,
                  Central Ethiopia </p>
              <p>Telephones: +251 916 1206 47</p>
              <p>E-mail: selefetumiso47@gmail.com</p>
        </div>
      </div>
    </div>
    </div>
  <p class="footer-bottom-text">CopyRights © Alright Reserve 2017 E.C</p>
</footer>