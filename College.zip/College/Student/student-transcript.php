&nbsp<!DOCTYPE html>
<html>
<?php  
	session_start();
	if (!$_SESSION["LoginStudent"])
	{
		header('location:../login/login.php');
	}
		require_once "../connection/connection.php";
?>
<head>
    <link rel="icon" href="images/logo.jpg">

    <title>Student Grading System</title>

     <!-- Bootstrap Core CSS -->
    <link href="asset/css/bootstrap.min.css" rel="stylesheet">
    <link href="asset/css/styles.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="asset/css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="asset/css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="asset/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    
    <script src="datatables/jquery.dataTables.js"></script>
    <script src="datatables/dataTables.bootstrap.js"></script>
        <link href="datatables/dataTables.bootstrap.css" rel="stylesheet">

    <script src="assets/js/jquery.min.js"></script>
    <script src="asset/js/bootstrap.min.js" type="text/javascript"></script>

    <script src="assets/js/ie-emulation-modes-warning.js"></script>
    <script src="assets/js/jq.js"></script>
	<style>
	@media print {  
		@page {
			size:8.5in 13in;
		}
		head{
			height:0px;
			display: none;
		}
		#head{
			display: none;
			height:0px;
		}
		#print{
		position:fixed;
		top:0px;
		margin-top:20px;
		margin-bottom:30px;
		margin-right:50px;
		margin-left:50px;
		}
		}
		#print{
		width:7.5in;
		}
		input {
    border: 0;
    outline: 0;
    background: transparent;
    border-bottom: 1px solid black;
}

.foo{
	font-family: "Bodoni MT", Didot, "Didot LT STD", "Hoefler Text", Garamond, "Times New Roman", serif;
	font-size: 24px;
	font-style: italic;
	font-variant: normal;
	font-weight: bold;
	line-height: 24px;
	}
	.p {
	font-family: "Segoe UI", Frutiger, "Frutiger Linotype", "Dejavu Sans", "Helvetica Neue", Arial, sans-serif;
	font-size: 14px;
	font-style: italic;
	font-variant: normal;
	font-weight: 550;
	line-height: 20px;
	 letter-spacing: 2px;
}
	</style>

</head> 
<body style="background-color:white"> 
<span id='returncode'></span>
<div class="col-md-2" id="head">
	<button class="btn btn-info" onclick="print()"><i class="glyphicon glyphicon-print"></i>PRINT</button>
	<a class="btn btn-info" onclick="window.close()">Cancel</a>
	
</div>
<center>
<div id='print'>
<div style="margin-left:.5in;margin-right:.5in;margin-top:.1in;margin-bottom:.1in;line-height:1mm;">
<div class="row">
		  <div class="col-md-12">
<center><img src="../Images/5.png" alt="" width="100" height="100"></center>
</div>
          </div>
		  <div class="row">
		  <div class="col-md-12">
<center><p><b><h3 class="text-dark mt-3">በማዕከላዊ ኢትዮጵያ ክልል በሀድያ ዞን የጊምቢቹ ኮንትራክሽንና ኢንዱስትሪያል </h3></b></p></center>
</div>
          </div>

<div class="row">
		  <div class="col-md-12">
		<center><p><b><h3></h3></b></p></center>
		</div>
          </div>
		  </div>
		  <div class="row">
		  <div class="col-md-12">
		 
		  </div>
          </div>
          <div class="container-fluid mb-4 text-dark">
        <div class="program-info">
            <?php  
                $roll_no = $_SESSION['LoginStudent'];
                $query = "select * from student_info inner join sessions on sessions.session=student_info.session where roll_no = '$roll_no'";
                $run = mysqli_query($con, $query);
                while($row = mysqli_fetch_array($run)){ ?>
                    <center><p><b><h3> ኮሌጅ_*TVET* Student Transcript - <?php echo $row['course_code']; ?> - Department</h3></b></p></center>
        </div>
        <div class="d-flex mt-3">
            <div>
			<h3> Student Name :<?php echo $row['first_name']. " ". $row['middle_name']. " ". $row['last_name']; ?>   I.D : <?php echo $row['roll_no']; ?></h3>
                
            </div>
            <div class="ml-auto">
			
			<center><p><b><h3>Year of Addmission : <?php echo intval($row['admission_date']) . " ". $row['session']; ?></h3></b></p></center>
            </div>
        </div>
        <?php }
        ?>
    </div>
          <div class="row">
          <div class="col-md-12">
          <hr style="border-color:black;border:1px solid black"></hr>
          </div>
          
          </div>

          <div class="row">
					<div class="col-md-12">
						<section class="mt-3">
							<table class="w-100 table-elements mb-5 table-three-tr" cellpadding="10" >
								<tr class="text-center text-white table-three table-tr-head">
									<th>Level</th>
									
									<th>UC of Code</th>
									<th>Cr.Hr</th>
									
									<th>Marks 100%</th>
									<th>Grade</th>
									<th>CGPA</th>
								</tr>
								<?php 
								$cgpa=0;
								$gpa=0;
								$total_marks=0;
								$obtain_marks=0;
								$count=0;
									$roll_no=$_SESSION['LoginStudent'];
									$query="select * from class_result cr inner join course_subjects cs on cr.subject_code=cs.subject_code where cr.roll_no='$roll_no'";
									$run=mysqli_query($con,$query);
									while ($row=mysqli_fetch_array($run)) { ?>
										<tr class="text-center">
											<td><?php echo $row['course_code']."-".$row['semester'] ?></td>
											
											<td><?php echo $row['subject_code'] ?></td>
											<td><?php echo $row['credit_hours'] ?></td>
											
											<td><?php echo $row['obtain_marks'] ?></td>
											<?php  
												if ($row['obtain_marks']>85) {
													$grade='A+';
													$credits=4.0;
												}
												else if ($row['obtain_marks']>80) {
													$grade='A';
													$credits=4.0;
												}
												else if ($row['obtain_marks']>75) {
													$grade='B+';
													$credits=3.7;
												}
												else if ($row['obtain_marks']>70) {
													$grade='B';
													$credits=3.3;
												}
												else if ($row['obtain_marks']>65) {
													$grade='C+';
													$credits=3.0;
												}
												else if ($row['obtain_marks']>60) {
													$grade='C';
													$credits=2.7;
												}
												else if ($row['obtain_marks']>55) {
													$grade='D+';
													$credits=2.5;

												}
												else if ($row['obtain_marks']>50) {
													$grade='D';
													$credits=2.0;
												}
												else {
													$grade='F';
													$credits=0.0;
												}
											?>
											<td><?php echo $grade ?></td>
											<td><?php echo $credits ?></td>
										</tr>
									<?php
										$count++; 
										$score=$credits*$row['credit_hours'];
										$gpa=$gpa+$score;
										$cgpa=$cgpa+$row['credit_hours'];
										$obtain_marks=$obtain_marks+$row['obtain_marks'];
										$total_marks=$total_marks+$row['total_marks'];
									}
								?>
								

								<tr class=" text-white bg-success text-center">
									<td><?php echo"***." ?></td>
									<td><?php echo"FINAL RESULT " ?></td>
									
									<td><?php echo "***."?></td>
									<td><?php echo "***." ?></td>
									
									<?php  
										$marks_grade= $total_marks == true ? ($obtain_marks*100)/$total_marks : "";
										$marks_grade=round($marks_grade);
										if ($marks_grade>85) {
											$final='A+';
										}
										else if ($marks_grade>80) {
											$final='A';										
										}
										else if ($marks_grade>75) {
											$final='B+';
										}
										else if ($marks_grade>70) {
											$final='B';
										}
										else if ($marks_grade>65) {
											$final='C+';
										}
										else if ($marks_grade>60) {
											$final='C';
										}
										else if ($marks_grade>55) {
											$final='D+';
										}
										else if ($marks_grade>50) {
											$final='D';
										}
										else {
											$marks_grade == true ? $final='F' : $final = "0";
										}
									?>
									
									<td><?php echo $final ?></td>
									<td><?php echo $gpa > 0 ? round($total_cgpa=$gpa/$cgpa,2) : "0" ?></td>

								</tr>

								
							</table>	
						</section>
					</div>
				</div>
		<table style="border-collapse:collapse">
			<tr>
		
		</tr>
		</table>
		</td>
		</tr>

		</td>
		</tr>

		</table>
		
		<?php 
	

		
	
	

		?>
      	<p>


<p style="float:left;marginleft:15px;margin-bottom:20px;">
<div class="col-md-12">
          <hr style="border-color:black;border:1px solid black"></hr>

         <table>
         <tr>
         	<td>
		<center><h3 class="foo"><b>CERTIFICATION</b></h3></center>	
		







		
			
		
			<table>
			<tr>
				<td align="left" style="width:500px">
					<h5>REMARKS:</h5>
				</td>
				<td style="">
					<table>
						
				
					
					<tr>
						<td>
							&nbsp
						</td>
					</tr>

						<tr>
							<td style="width:250px;border-bottom:1px solid black">
								
							</td>
						</tr>
						<tr>
						<td style="width:250px;">
							<center><h5>PRINCIPAL</h5></center>
						</td>
					</tr>
					</table>
				</td>

			</tr>
			</table>
         	</td>
         </tr>
         </table>

</div>
</p>


</center>
</body>
<script>
function printContent(el){
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
	window.print();
	document.body.innerHTML = restorepage;

	$.ajax({
		url:'print_log.php?act=student_transcript&id=<?php echo $_GET['id'] ?>',
		success:function(html){
			$('#returncode').html(html);
		}
	});
}
</script>
</html>