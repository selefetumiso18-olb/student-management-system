-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2026 at 07:55 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imperial_college`
--

-- --------------------------------------------------------

--
-- Table structure for table `class_result`
--

CREATE TABLE `class_result` (
  `class_result_id` int(11) NOT NULL,
  `roll_no` varchar(30) NOT NULL,
  `course_code` varchar(30) NOT NULL,
  `subject_code` varchar(10) NOT NULL,
  `semester` varchar(11) NOT NULL,
  `total_marks` varchar(11) NOT NULL,
  `obtain_marks` varchar(11) NOT NULL,
  `result_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_result`
--

INSERT INTO `class_result` (`class_result_id`, `roll_no`, `course_code`, `subject_code`, `semester`, `total_marks`, `obtain_marks`, `result_date`) VALUES
(68, 'IT/53/15', 'ICT', 'HNS1_MO1', '1', '100', '75', '26-07-25'),
(69, 'IT/53/15', 'ICT', 'HNS1_MO2', '1', '100', '75', '26-07-25'),
(70, 'IT/53/15', 'ICT', 'HNS1_MO3', '1', '100', '90', '26-07-25'),
(71, 'IT/53/15', 'ICT', 'HNS1_MO4', '1', '100', '80', '26-07-25'),
(72, 'IT/53/15', 'ICT', 'HNS1_MO5', '1', '100', '67', '26-07-25'),
(73, 'IT/53/15', 'ICT', 'HNS1_MO7', '1', '100', '75', '26-07-25'),
(74, 'IT/53/15', 'ICT', 'HNS1_MO8', '1', '100', '67', '26-07-25'),
(75, 'IT/53/15', 'ICT', 'HNS1_MO9', '1', '100', '96', '26-07-25'),
(76, 'IT/53/15', 'ICT', 'HNS2_M01', '2', '100', '80', '26-07-25'),
(78, 'IT/53/15', 'ICT', 'HNS2_MO2', '2', '100', '96', '26-07-25'),
(79, 'IT/53/15', 'ICT', 'HNS2_M03', '2', '100', '67', '26-07-25'),
(80, 'IT/53/15', 'ICT', 'HNS2_M04', '2', '100', '96', '26-07-25'),
(81, 'IT/53/15', 'ICT', 'HNS2_M05', '2', '100', '75', '26-07-25'),
(82, 'IT/53/15', 'ICT', 'HNS2_MO6', '2', '100', '90', '26-07-25'),
(83, 'IT/53/15', 'ICT', 'HNS2_MO7', '2', '100', '96', '26-07-25'),
(84, 'IT/53/15', 'ICT', 'HNS3_M01', '3', '100', '96', '27-07-25'),
(85, 'IT/53/15', 'ICT', 'HNS3_M02', '3', '100', '75', '27-07-25'),
(86, 'IT/53/15', 'ICT', 'HNS3_M03', '3', '100', '90', '27-07-25'),
(87, 'IT/53/15', 'ICT', 'HNS3_M04', '3', '100', '90', '27-07-25'),
(88, 'IT/53/15', 'ICT', 'HNS3_M05', '3', '100', '96', '27-07-25'),
(89, 'IT/53/15', 'ICT', 'HNS3_M06', '3', '100', '96', '27-07-25'),
(90, 'IT/53/15', 'ICT', 'HNS3_M7', '3', '100', '75', '27-07-25'),
(91, 'IT/53/15', 'ICT', 'HNS4_M1', '4', '100', '75', '27-07-25'),
(92, 'IT/53/15', 'ICT', 'HNS4_M2', '4', '100', '90', '27-07-25'),
(93, 'IT/53/15', 'ICT', 'HNS4_M03', '4', '100', '96', '27-07-25'),
(94, 'IT/53/15', 'ICT', 'HNS4_M04', '4', '100', '90', '27-07-25'),
(95, 'IT/53/15', 'ICT', 'HNS4_M05', '4', '100', '80', '27-07-25'),
(96, 'IT/53/15', 'ICT', 'HNS4_M07', '4', '100', '75', '27-07-25');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_code` varchar(10) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `semester_or_year` varchar(10) NOT NULL,
  `no_of_year` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_code`, `course_name`, `semester_or_year`, `no_of_year`) VALUES
('BEI', '1_4', '8', 4),
('ICT', '1_4', '4', 2);

-- --------------------------------------------------------

--
-- Table structure for table `course_subjects`
--

CREATE TABLE `course_subjects` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `semester` int(10) NOT NULL,
  `credit_hours` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_subjects`
--

INSERT INTO `course_subjects` (`subject_code`, `subject_name`, `course_code`, `semester`, `credit_hours`) VALUES
(' HNS3_M03', ' HNS3_M03_Installing and managing Network Protocol', 'ICT', 3, 40),
(' HNS3_M06', ' HNS3_M06_Providing First Level Remote Help Desk ', 'ICT', 3, 20),
(' HNS3_M7', ' HNS3_M7_Creating Technical Documentation', 'ICT', 3, 20),
('HNS1_MO1', 'HNS1_MO1_Operating Personal Computer', 'ICT', 1, 80),
('HNS1_MO2', 'HNS1_MO2_Connecting Hardware  Peripherals ', 'ICT', 1, 60),
('HNS1_MO3', 'HNS1_MO3_Installing  Software Application  ', 'ICT', 1, 40),
('HNS1_MO4', 'HNS1_MO4_Creating and use Spreadsheets', 'ICT', 1, 80),
('HNS1_MO5', 'HNS1_MO5_Applying Quality Standards', 'ICT', 1, 20),
('HNS1_MO6', 'HNS1_MO6_Protecting  Application or System Softwar', 'ICT', 1, 60),
('HNS1_MO7', 'HNS1_MO7_Maintaining Inventories of Equipment, Sof', 'ICT', 1, 30),
('HNS1_MO8', 'HNS1_MO8_Identifying and Using Network Hand Tools', 'ICT', 1, 20),
('HNS1_MO9', 'HNS1_MO9_Recording  Client Support Requirements', 'ICT', 1, 30),
('HNS2_M01', 'HNS2_M01_Network & Computer Hardware', 'ICT', 2, 30),
('HNS2_M03 ', 'HNS2_M03_Applying  Problem –  Solving', 'ICT', 2, 30),
('HNS2_M04', 'HNS2_M04_Maintenance Procedure', 'ICT', 2, 30),
('HNS2_M05', 'HNS2_M05_Updating and Documenting Operational Proc', 'ICT', 2, 40),
('HNS2_MO2', 'HNS2_MO2_Connecting Internal Hardware Component', 'ICT', 2, 40),
('HNS2_MO6', 'HNS2_MO6_Record Client Support Requirements', 'ICT', 2, 30),
('HNS2_MO7', 'HNS2_MO7_Prevent and Eliminate MUDA', 'ICT', 2, 30),
('HNS3_M01 ', 'HNS3_M01_Determining Best-Fit Topology', 'ICT', 3, 50),
('HNS3_M02 ', 'HNS3_M02_Configure and Administer Server', 'ICT', 3, 80),
('HNS3_M04', 'HNS3_M04_Monitor and Administer System and Network', 'ICT', 3, 30),
('HNS3_M05', 'HNS3_M05_Identifying and Resolve Network Problems', 'ICT', 3, 30),
('HNS4_M03 ', 'HNS4_M03_Building a small wireless LAN', 'ICT', 4, 40),
('HNS4_M04', 'HNS4_M04_Providing Network System Administration', 'ICT', 4, 45),
('HNS4_M05', 'HNS4_M05_Managing  network security', 'ICT', 4, 45),
('HNS4_M06', 'HNS4_M06_Determining Maintenance Strategy', 'ICT', 4, 30),
('HNS4_M07', 'HNS4_M07_ Conducting/ Facilitate User Training', 'ICT', 4, 30),
('HNS4_M1', 'HNS4_M1_Developing System Infrastructure Design Pl', 'ICT', 4, 50),
('HNS4_M2', 'HNS4_M2_Building Internet Infrastructure', 'ICT', 4, 60);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Role` varchar(10) NOT NULL,
  `account` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `user_id`, `Password`, `Role`, `account`) VALUES
(2, 'admin@gmail.com', 'admin123*', 'Admin', ''),
(6, 'sele@gmail.com', 'teacher123*', 'Teacher', 'Activate'),
(301, 'IT/53/15', 'student123*', 'Student', 'Activate');

-- --------------------------------------------------------

--
-- Table structure for table `mytable`
--

CREATE TABLE `mytable` (
  `id` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `course_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `session_id` int(11) NOT NULL,
  `session` varchar(30) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`session_id`, `session`, `created_date`) VALUES
(1, 'S19', '2020-03-11 20:20:44');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE `student_attendance` (
  `attendance_id` int(11) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `subject_code` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `attendance` int(11) NOT NULL,
  `attendance_date` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_courses`
--

CREATE TABLE `student_courses` (
  `student_course_id` int(11) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `roll_no` varchar(10) NOT NULL,
  `subject_code` varchar(10) NOT NULL,
  `session` varchar(10) NOT NULL,
  `assign_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_courses`
--

INSERT INTO `student_courses` (`student_course_id`, `course_code`, `semester`, `roll_no`, `subject_code`, `session`, `assign_date`) VALUES
(147, 'ICT', 1, 'IT/53/15', 'HNS1_MO1', 'S19', '26-07-25'),
(148, 'ICT', 3, 'IT/53/15', 'HNS3_M03', '', '26-07-25'),
(149, 'ICT', 3, 'IT/53/15', 'HNS3_M06', '', '26-07-25'),
(150, 'ICT', 3, 'IT/53/15', 'HNS3_M7', '', '26-07-25'),
(151, 'ICT', 1, 'IT/53/15', 'HNS1_MO1', '', '26-07-25'),
(152, 'ICT', 1, 'IT/53/15', 'HNS1_MO2', '', '26-07-25'),
(153, 'ICT', 1, 'IT/53/15', 'HNS1_MO3', '', '26-07-25'),
(154, 'ICT', 1, 'IT/53/15', 'HNS1_MO4', '', '26-07-25'),
(155, 'ICT', 1, 'IT/53/15', 'HNS1_MO5', '', '26-07-25'),
(156, 'ICT', 1, 'IT/53/15', 'HNS1_MO6', '', '26-07-25'),
(157, 'ICT', 1, 'IT/53/15', 'HNS1_MO7', '', '26-07-25'),
(158, 'ICT', 1, 'IT/53/15', 'HNS1_MO8', '', '26-07-25'),
(159, 'ICT', 1, 'IT/53/15', 'HNS1_MO9', '', '26-07-25'),
(160, 'ICT', 2, 'IT/53/15', 'HNS2_M01', '', '26-07-25'),
(161, 'ICT', 2, 'IT/53/15', 'HNS2_M03', '', '26-07-25'),
(162, 'ICT', 2, 'IT/53/15', 'HNS2_M04', '', '26-07-25'),
(163, 'ICT', 2, 'IT/53/15', 'HNS2_M05', '', '26-07-25'),
(164, 'ICT', 2, 'IT/53/15', 'HNS2_MO2', '', '26-07-25'),
(165, 'ICT', 2, 'IT/53/15', 'HNS2_MO6', '', '26-07-25'),
(166, 'ICT', 2, 'IT/53/15', 'HNS2_MO7', '', '26-07-25'),
(167, 'ICT', 3, 'IT/53/15', 'HNS3_M01', '', '26-07-25'),
(168, 'ICT', 3, 'IT/53/15', 'HNS3_M02', '', '26-07-25'),
(169, 'ICT', 3, 'IT/53/15', 'HNS3_M04', '', '26-07-25'),
(170, 'ICT', 3, 'IT/53/15', 'HNS3_M05', '', '26-07-25'),
(171, 'ICT', 4, 'IT/53/15', 'HNS4_M03', '', '26-07-25'),
(172, 'ICT', 4, 'IT/53/15', 'HNS4_M04', '', '26-07-25'),
(173, 'ICT', 4, 'IT/53/15', 'HNS4_M05', '', '26-07-25'),
(174, 'ICT', 4, 'IT/53/15', 'HNS4_M06', '', '26-07-25'),
(175, 'ICT', 4, 'IT/53/15', 'HNS4_M07', '', '26-07-25'),
(176, 'ICT', 4, 'IT/53/15', 'HNS4_M1', '', '26-07-25'),
(177, 'ICT', 4, 'IT/53/15', 'HNS4_M2', '', '26-07-25');

-- --------------------------------------------------------

--
-- Table structure for table `student_fee`
--

CREATE TABLE `student_fee` (
  `fee_voucher` int(11) NOT NULL,
  `roll_no` varchar(30) NOT NULL,
  `amount` int(11) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_fee`
--

INSERT INTO `student_fee` (`fee_voucher`, `roll_no`, `amount`, `posting_date`, `status`) VALUES
(6, 'IT/53/15', 500, '2025-07-27 15:58:25', 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `roll_no` varchar(20) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `middle_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `father_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `course_code` varchar(11) NOT NULL,
  `session` varchar(10) NOT NULL,
  `profile_image` varchar(100) NOT NULL,
  `prospectus_issued` varchar(10) NOT NULL,
  `prospectus_amount` varchar(10) NOT NULL,
  `form_b` varchar(20) NOT NULL,
  `applicant_status` varchar(20) NOT NULL,
  `application_status` varchar(20) NOT NULL,
  `cnic` varchar(15) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `other_phone` varchar(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `permanent_address` varchar(150) NOT NULL,
  `current_address` varchar(150) NOT NULL,
  `place_of_birth` varchar(150) NOT NULL,
  `matric_complition_date` varchar(10) NOT NULL,
  `matric_awarded_date` varchar(10) NOT NULL,
  `matric_certificate` varchar(100) NOT NULL,
  `fa_complition_date` varchar(10) NOT NULL,
  `fa_awarded_date` varchar(10) NOT NULL,
  `fa_certificate` varchar(100) NOT NULL,
  `ba_complition_date` varchar(10) NOT NULL,
  `ba_awarded_date` varchar(10) NOT NULL,
  `ba_certificate` varchar(100) NOT NULL,
  `semester` int(11) NOT NULL,
  `total_marks` int(11) NOT NULL,
  `obtain_marks` int(11) NOT NULL,
  `state` varchar(20) NOT NULL,
  `admission_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`roll_no`, `first_name`, `middle_name`, `last_name`, `father_name`, `email`, `mobile_no`, `course_code`, `session`, `profile_image`, `prospectus_issued`, `prospectus_amount`, `form_b`, `applicant_status`, `application_status`, `cnic`, `dob`, `other_phone`, `gender`, `permanent_address`, `current_address`, `place_of_birth`, `matric_complition_date`, `matric_awarded_date`, `matric_certificate`, `fa_complition_date`, `fa_awarded_date`, `fa_certificate`, `ba_complition_date`, `ba_awarded_date`, `ba_certificate`, `semester`, `total_marks`, `obtain_marks`, `state`, `admission_date`) VALUES
('IT/53/15', 'Abiyu', 'Gimiso', 'Gadiso', 'Gimiso', 'abiyu@gmail.com', '0912131211', 'ICT', 'S19', '', 'Yes', 'Yes', 'B', 'Admitted', 'Approved', '1000', '1983-09-09', '', 'Male', 'Gimbichu', 'Gimbichu', 'Gimbichu', '', '', '', '', '', '', '', '', '', 0, 0, 0, '', '2025-07-26 15:40:16');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_attendance`
--

CREATE TABLE `teacher_attendance` (
  `attendance_id` int(11) NOT NULL,
  `teacher_id` varchar(30) NOT NULL,
  `attendance` int(11) NOT NULL,
  `attendance_date` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_courses`
--

CREATE TABLE `teacher_courses` (
  `teacher_courses_id` int(11) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `teacher_id` varchar(10) NOT NULL,
  `subject_code` varchar(10) NOT NULL,
  `assign_date` varchar(10) NOT NULL,
  `total_classes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_courses`
--

INSERT INTO `teacher_courses` (`teacher_courses_id`, `course_code`, `semester`, `teacher_id`, `subject_code`, `assign_date`, `total_classes`) VALUES
(23, 'ICT', 1, '3', 'HNS1_MO1', '26-07-25', 3),
(24, 'ICT', 1, '3', 'HNS1_MO2', '26-07-25', 3),
(25, 'ICT', 1, '3', 'HNS1_MO3', '26-07-25', 3),
(26, 'ICT', 1, '3', 'HNS1_MO4', '26-07-25', 3),
(27, 'ICT', 1, '3', 'HNS1_MO5', '26-07-25', 3),
(28, 'ICT', 1, '3', 'HNS1_MO6', '26-07-25', 3),
(29, 'ICT', 1, '3', 'HNS1_MO7', '26-07-25', 3),
(30, 'ICT', 1, '3', 'HNS1_MO8', '26-07-25', 3),
(31, 'ICT', 1, '3', 'HNS1_MO9', '26-07-25', 3),
(32, 'ICT', 2, '3', 'HNS2_M01', '26-07-25', 5),
(33, 'ICT', 2, '3', 'HNS2_MO2', '26-07-25', 3),
(34, 'ICT', 2, '3', 'HNS2_M03', '26-07-25', 3),
(35, 'ICT', 2, '3', 'HNS2_M04', '26-07-25', 3),
(36, 'ICT', 2, '3', 'HNS2_M05', '26-07-25', 3),
(37, 'ICT', 2, '3', 'HNS2_MO6', '26-07-25', 3),
(38, 'ICT', 2, '3', 'HNS2_MO7', '26-07-25', 5),
(39, 'ICT', 3, '3', 'HNS3_M01', '27-07-25', 3),
(40, 'ICT', 3, '3', 'HNS3_M02', '27-07-25', 3),
(41, 'ICT', 3, '3', 'HNS3_M03', '27-07-25', 3),
(42, 'ICT', 3, '3', 'HNS3_M04', '27-07-25', 3),
(43, 'ICT', 3, '3', 'HNS3_M05', '27-07-25', 3),
(44, 'ICT', 3, '3', 'HNS3_M06', '27-07-25', 3),
(45, 'ICT', 3, '3', 'HNS3_M7', '27-07-25', 3),
(46, 'ICT', 4, '3', 'HNS4_M1', '27-07-25', 3),
(47, 'ICT', 4, '3', 'HNS4_M2', '27-07-25', 3),
(48, 'ICT', 4, '3', 'HNS4_M03', '27-07-25', 3),
(49, 'ICT', 4, '3', 'HNS4_M04', '27-07-25', 3),
(50, 'ICT', 4, '3', 'HNS4_M05', '27-07-25', 3),
(51, 'ICT', 4, '3', 'HNS4_M06', '27-07-25', 3),
(52, 'ICT', 4, '3', 'HNS4_M07', '27-07-25', 3);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_info`
--

CREATE TABLE `teacher_info` (
  `teacher_id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `middle_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_no` varchar(11) NOT NULL,
  `profile_image` blob NOT NULL,
  `teacher_status` varchar(10) NOT NULL,
  `application_status` varchar(10) NOT NULL,
  `cnic` varchar(15) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `other_phone` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `permanent_address` varchar(100) NOT NULL,
  `current_address` varchar(100) NOT NULL,
  `place_of_birth` varchar(50) NOT NULL,
  `matric_complition_date` varchar(10) NOT NULL,
  `matric_awarded_date` varchar(10) NOT NULL,
  `matric_certificate` varchar(100) NOT NULL,
  `fa_complition_date` varchar(10) NOT NULL,
  `fa_awarded_date` varchar(10) NOT NULL,
  `fa_certificate` varchar(100) NOT NULL,
  `ba_complition_date` varchar(10) NOT NULL,
  `ba_awarded_date` varchar(10) NOT NULL,
  `ba_certificate` varchar(100) NOT NULL,
  `ma_complition_date` varchar(10) NOT NULL,
  `ma_awarded_date` varchar(100) NOT NULL,
  `ma_certificate` varchar(101) NOT NULL,
  `last_qualification` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `hire_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_info`
--

INSERT INTO `teacher_info` (`teacher_id`, `first_name`, `middle_name`, `last_name`, `father_name`, `email`, `phone_no`, `profile_image`, `teacher_status`, `application_status`, `cnic`, `dob`, `other_phone`, `gender`, `permanent_address`, `current_address`, `place_of_birth`, `matric_complition_date`, `matric_awarded_date`, `matric_certificate`, `fa_complition_date`, `fa_awarded_date`, `fa_certificate`, `ba_complition_date`, `ba_awarded_date`, `ba_certificate`, `ma_complition_date`, `ma_awarded_date`, `ma_certificate`, `last_qualification`, `state`, `hire_date`) VALUES
(3, 'Selefe', 'Tumiso', 'Olbamo', '', 'sele@gmail.com', '0916120647', 0x32303230313031303030303835353134382e69636f, 'Permanent', 'Yes', '1000', '0085-12-15', 2147483647, 'Male', 'Hossana', 'Hossan', 'Gimbichu', '2000-11-13', '2004-07-12', '20201010000855148.ico', '', '', '', '', '', '', '', '', '', '', '', '27-11-24');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_salary_allowances`
--

CREATE TABLE `teacher_salary_allowances` (
  `teacher_id` int(11) NOT NULL,
  `basic_salary` int(11) NOT NULL,
  `medical_allowance` int(11) NOT NULL,
  `hr_allowance` int(11) NOT NULL,
  `scale` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_salary_report`
--

CREATE TABLE `teacher_salary_report` (
  `salary_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `status` varchar(11) NOT NULL,
  `paid_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `time_table`
--

CREATE TABLE `time_table` (
  `id` int(11) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `timing_from` varchar(10) NOT NULL,
  `timing_to` varchar(10) NOT NULL,
  `day` varchar(20) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `room_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `time_table`
--

INSERT INTO `time_table` (`id`, `course_code`, `semester`, `timing_from`, `timing_to`, `day`, `subject_code`, `room_no`) VALUES
(32, 'ICT', 1, '14:03', '18:03', '1', 'HNS1_MO1', 1),
(34, 'ICT', 1, '14:03', '18:03', '2', 'HNS1_MO3', 1),
(35, 'ICT', 1, '14:03', '18:03', '5', 'HNS1_MO4', 1),
(36, 'ICT', 1, '14:03', '18:03', '2', 'HNS1_MO5', 1),
(37, 'ICT', 1, '14:03', '18:03', '2', 'HNS1_MO6', 1),
(38, 'ICT', 1, '14:03', '18:03', '4', 'HNS1_MO7', 1),
(40, 'ICT', 1, '14:03', '18:03', '4', 'HNS1_MO9', 1),
(41, 'ICT', 1, '14:03', '18:03', '3', 'HNS1_MO8', 1),
(42, 'ICT', 0, '14:03', '18:03', '3', 'HNS1_MO2', 1),
(43, 'ICT', 2, '14:03', '18:03', '3', 'HNS2_M01', 3),
(44, 'ICT', 2, '18:03', '14:03', '2', 'HNS2_MO2', 3),
(45, 'ICT', 2, '14:03', '18:03', '2', 'HNS2_M03', 2),
(46, 'ICT', 2, '14:03', '18:02', '2', 'HNS2_M04', 2),
(47, 'ICT', 2, '14:03', '14:03', '5', 'HNS2_M05', 2),
(48, 'ICT', 2, '14:03', '18:03', '6', 'HNS2_MO6', 2),
(49, 'ICT', 2, '14:03', '18:03', '3', 'HNS2_MO7', 2),
(50, 'ICT', 3, '14:03', '18:03', '6', 'HNS3_M01', 3),
(51, 'ICT', 3, '14:03', '17:06', '4', 'HNS3_M02', 3),
(52, 'ICT', 3, '14:03', '18:03', '3', 'HNS3_M03', 3),
(53, 'ICT', 3, '14:03', '18:03', '4', 'HNS3_M04', 3),
(54, 'Select Dep', 0, '14:03', '18:03', '3', 'HNS3_M05', 3),
(55, 'ICT', 3, '14:03', '18:03', '3', 'HNS3_M06', 3),
(56, 'ICT', 3, '14:03', '18:02', '2', 'HNS3_M7', 3),
(57, 'ICT', 4, '14:03', '18:03', '3', 'HNS4_M1', 4),
(58, 'ICT', 4, '14:03', '18:03', '3', 'HNS4_M2', 4),
(59, 'ICT', 4, '14:03', '18:03', '3', 'HNS4_M03', 4),
(60, 'ICT', 4, '14:03', '17:02', '2', 'HNS4_M04', 4),
(61, 'ICT', 4, '14:03', '18:03', '3', 'HNS4_M05', 4),
(62, 'ICT', 4, '14:03', '18:02', '2', 'HNS4_M06', 4),
(63, 'ICT', 4, '14:03', '15:05', '2', 'HNS4_M07', 4);

-- --------------------------------------------------------

--
-- Table structure for table `weekdays`
--

CREATE TABLE `weekdays` (
  `day_id` int(11) NOT NULL,
  `day_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `weekdays`
--

INSERT INTO `weekdays` (`day_id`, `day_name`) VALUES
(1, 'Monday'),
(2, 'Tuesday'),
(3, 'Wednesday'),
(4, 'Thursday'),
(5, 'Friday'),
(6, 'Saturday'),
(7, 'Sunday');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class_result`
--
ALTER TABLE `class_result`
  ADD PRIMARY KEY (`class_result_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_code`);

--
-- Indexes for table `course_subjects`
--
ALTER TABLE `course_subjects`
  ADD PRIMARY KEY (`subject_code`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `mytable`
--
ALTER TABLE `mytable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `student_courses`
--
ALTER TABLE `student_courses`
  ADD PRIMARY KEY (`student_course_id`),
  ADD KEY `course_code` (`course_code`);

--
-- Indexes for table `student_fee`
--
ALTER TABLE `student_fee`
  ADD PRIMARY KEY (`fee_voucher`),
  ADD KEY `roll_no` (`roll_no`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`roll_no`);

--
-- Indexes for table `teacher_attendance`
--
ALTER TABLE `teacher_attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `teacher_courses`
--
ALTER TABLE `teacher_courses`
  ADD PRIMARY KEY (`teacher_courses_id`);

--
-- Indexes for table `teacher_info`
--
ALTER TABLE `teacher_info`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `teacher_salary_allowances`
--
ALTER TABLE `teacher_salary_allowances`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `teacher_salary_report`
--
ALTER TABLE `teacher_salary_report`
  ADD PRIMARY KEY (`salary_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `time_table`
--
ALTER TABLE `time_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `weekdays`
--
ALTER TABLE `weekdays`
  ADD PRIMARY KEY (`day_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class_result`
--
ALTER TABLE `class_result`
  MODIFY `class_result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_attendance`
--
ALTER TABLE `student_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `student_courses`
--
ALTER TABLE `student_courses`
  MODIFY `student_course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;

--
-- AUTO_INCREMENT for table `student_fee`
--
ALTER TABLE `student_fee`
  MODIFY `fee_voucher` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `teacher_attendance`
--
ALTER TABLE `teacher_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `teacher_courses`
--
ALTER TABLE `teacher_courses`
  MODIFY `teacher_courses_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `teacher_info`
--
ALTER TABLE `teacher_info`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teacher_salary_report`
--
ALTER TABLE `teacher_salary_report`
  MODIFY `salary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `time_table`
--
ALTER TABLE `time_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `weekdays`
--
ALTER TABLE `weekdays`
  MODIFY `day_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `teacher_salary_report`
--
ALTER TABLE `teacher_salary_report`
  ADD CONSTRAINT `teacher_salary_report_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teacher_salary_allowances` (`teacher_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
