<!DOCTYPE html>
<html>
<head>
	<title>Academics</title>
</head>
<body>
	<?php include('common/header.php') ?>
	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Department of Informetion and Technology</h4>
			</div>
			<div class="container">
				<div class="row">
		
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Department of Engineering and Technology</h4>
			</div>
			<div class="container">
				<div class="row">
					
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Department of Computer Sciences</h4>
			</div>
			<div class="container">
				<div class="row">
					
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row mb-5">
			<div class="academic-area-headings">
				<h4 class="py-4">Department of Electronics and Electric City</h4>
			</div>
			<div class="container">
				<div class="row">
						
				</div>
			</div>
		</div>
	</div>
</body>
</html>